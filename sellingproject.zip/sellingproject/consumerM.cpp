#include"consumer.h"
#include "shoppingCart.h"
#include"feedback.h"
consumer::~consumer()
{
	delete C_shoppingCart;
	if (S_order != nullptr)
		delete S_order;
}
//______________________________________________________________________________________________________________________
bool consumer::C_checkValidity(const adress& ad, const char *userName, const char* password)
{
	if (strlen(userName) != (USER_NAME_LENGTH-1) || strlen(password) != (PASSWORD_LENGTH-1))
	{
		return false;
	}
	return true;
}
//____________________________________________________________________________________________________________________________
void consumer::C_init(const adress& ad, const char*userName, const char*password)
{
	C_setAdrees(ad);
	C_setPassword(password);
	C_setUsername(userName);
	C_shoppingCart = new shoppingCart (userName,this);
	
}
//______________________________________________________________________________________________________________________________
void consumer::C_setAdrees(const adress& ad)
{
	C_adress.A_setCity(ad.A_getcity());
	C_adress.A_setStreet(ad.A_getStreet());
	C_adress.A_setHouseNumber(ad.A_getNumber());
}
//___________________________________________________________________________________________________________________
void consumer::C_setUsername(const char*userName)
{
	strcpy(C_userName, userName);
}
//_____________________________________________________________________________________________________________________
void consumer::C_setPassword(const char*password)
{
	strcpy(C_password, password);
}
//_______________________________________________________________________________________________________________________
void consumer::s_printConsumerShoppingCart()				const
{
	C_shoppingCart->S_shoppingCartPrint();
}
//__________________________________________________________________________________________________________
consumer::consumer(const adress& ad, const char *userName, const char* password)
{
	C_init(ad, userName, password);
	S_order = nullptr;//we will allocate the needed memory after the consumer will enter the order opption
}
//_____________________________________________________________________________________________________________________________
void consumer::C_addProductToCart(product *newProduct)
{
	C_shoppingCart->S_addproduct(newProduct);
}
//________________________________________________________________________________________//this function is printing the consumer , if we print it with the old print function we get infinity Loop
void consumer::printConsumerBelongeToShopping()           const
{
	cout << C_password<<"     " << C_userName << endl;
	C_adress.A_adressPrint();
}
//_____________________________________________________________________________________________________________________________
const feedback& consumer::addFeedBack(const char* date, const  consumer* cons, const  feedback::F_evaluaton& evaluation, const char* name)
{
	feedback newFeedback(date, cons, evaluation, name);
	return newFeedback;
}
//_____________________________________________________________________________________________________________________________
const adress& consumer::C_getAdress()					const
{
	return C_adress;
}
//_____________________________________________________________________________________________________________________________
const char* consumer::C_getName()						const
{
	return C_userName;
}
//_____________________________________________________________________________________________________________________________
const char* consumer::C_getPassword()					const
{
	return C_password;
}

//___________________________________________________________________________________________________________


//__________________________________________________________________________________________________________
shoppingCart * consumer::C_getShoppingcart()											const
{
	return C_shoppingCart;
}
//_____________________________________________________________________________________________________________________________
order * consumer::C_getOrder()
{
	return S_order;
}
//_____________________________________________________________________________________________________________________________
void consumer::C_setOrder( )
{
	S_order = new order(C_shoppingCart);
}
//______________________________________________________________________________________________________________________________
void consumer::C_setShoppingCart()
{
	C_shoppingCart = new shoppingCart(C_userName, this);
}