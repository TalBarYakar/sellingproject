#ifndef _CO_H
#define _CO_H
#include"product.h"
#include"feedback.h"
class shoppingCart;
class order;
class consumer 
{
public:
	friend class appSystem;
	friend class feedback;
	~consumer();
	consumer(const adress& ad, const char *userName, const char* password);
	static const int PASSWORD_LENGTH = 6;
	static const int USER_NAME_LENGTH = 10;
	bool C_checkValidity(const adress& ad, const char *userName, const char* password);// befor we will make new consumer we want to check that the input is valid
	void C_init(const adress& ad, const char*userName, const char*password);
	void C_setAdrees(const adress& ad);
	void C_setUsername(const char*userName);
	void C_setPassword(const char*password);
	void s_printConsumerShoppingCart()																							const;
	void C_addProductToCart(product *newProduct);
	void printConsumerBelongeToShopping()																						const;
	const feedback& addFeedBack(const char* date, const  consumer* cons, const  feedback::F_evaluaton& evaluation, const char* name);
	const adress& C_getAdress()																									const;
	const char* C_getName()																										const;
	const char* C_getPassword()																									const;
	//void  AS_orderForConsumer();
	void C_setOrder( );
	void C_setShoppingCart( );
	shoppingCart * C_getShoppingcart()																							const;	
	order * C_getOrder();
	
private:
	consumer(const consumer& other) = delete;// we dont want to have the possibility of copy consumers.
	shoppingCart *C_shoppingCart;// after making shoppingcart class iwill make the shopping cart into array and not pointer 
	adress C_adress;
	char C_userName[USER_NAME_LENGTH];
	char C_password[PASSWORD_LENGTH];
	order	*S_order;// we will convert order into regular varible and not a pointer
};
#endif // !_CO_H

