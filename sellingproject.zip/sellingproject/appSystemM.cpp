#include "appSystem.h"
#include"shoppingCart.h"
//___________________________________________________________________
appSystem::~appSystem()
{
	for (int i = 0; i < AS_logicOfConsumer; i++)
		delete AS_arrayOfconsumer[i];
	delete[] AS_arrayOfconsumer;
	for (int j = 0; j < AS_logicOfSeller; j++)
		delete AS_arrayOfSeller[j];
	delete[] AS_arrayOfSeller;
}
//______________________________________________________________________
appSystem::appSystem()
{
	AS_updateArrays();
}
//___________________________________________________________________________________________________________________________________________________________
seller* appSystem::AS_returnExistSeller(const char* name, const char* password) const //the function will return the seller which has the username and password as ask for
{
	int i = 0;
	while (i < AS_logicOfSeller)
	{
		if (strcmp(name, AS_arrayOfSeller[i]->SE_getName()) == 0)
			break;
		i++;
	}
	if (i == AS_logicOfSeller)
	{
		cout << "the User isnt exist" << endl;
		return nullptr;
	}
	else
	{
		if (strcmp(password, AS_arrayOfSeller[i]->SE_getPassword()) == 0)
			return AS_arrayOfSeller[i];
		else
			cout << "the password is Inncorect" << endl;
		return nullptr;
	}

}
//_________________________________________________________________________________________________________________________
void appSystem::AS_displayForSeller()// if the user is a seller that is his menu
{
	bool stop = false;
	int i;
	system("cls");//clear the screen
	cout << "for main menue -0   for new seller -1              for old seller -2       " << endl;
	cin >> i;
	switch (i)
	{
	case 0:
	{
		stop = true;
		break;
	}
	case 1:
	{
		seller *newptr = nullptr;
		while (newptr == nullptr && stop == false)
		{
			newptr= AS_createNewSeller();
			if (newptr != nullptr)// if the input is valid 
			{
				AS_addSeller(newptr);
				AS_menuForSeller(newptr);// sending him to the seller menu
			}
			else
			{
				system("cls");
				cout << "the input is not valid .  try again-0    exit-1" << endl;

				cin >> stop;
			}
		}
		break;
	}
	case 2://the userName is already exist
	{
		cout << " your userName is?" << endl;
		char Username[appSystem::MAXSIZEINPUT];
		cin.ignore();
		cin .getline(Username,MAXSIZEINPUT);
		cout << "type your password is?" << endl;
		char password[appSystem::MAXSIZEINPUT];
		cin.getline(password, MAXSIZEINPUT);
		seller *existSeller = nullptr;
		existSeller =AS_returnExistSeller(Username, password);//if the user is exist and the password and user name are fit to each other 
		if (existSeller != nullptr)
			AS_menuForSeller(existSeller);
		else
		{
			cout << "one of the details wasnot correct" << endl;
			_sleep(1500);
			break;
		}
		break;
	}
		
	default:
		break;
	}

}
//____________________________________________________________________________________________________________________________
consumer* appSystem::returnExistConsumer(const char*name, const char*password)			const// if the consumer is exist that function will retuen his adress
{
	int i = 0;
	cout << AS_logicOfConsumer << endl;
	while (i < AS_logicOfConsumer)
	{
		if (strcmp(name, AS_arrayOfconsumer[i]->C_getName()) == 0)
			break;
		i++;
	}
	if (i == AS_logicOfConsumer)
	{
		cout << "the User isnt exist" << endl;
		return nullptr;
	}// in case there is user name with the specific name as ask for
	else	
	{
		if (strcmp(password, AS_arrayOfconsumer[i]->C_getPassword()) == 0)// check if the password typed is fit to the user name
			return AS_arrayOfconsumer[i];
		else
			cout << "the password isInncorect" << endl;
		return nullptr;
	}

}
//___________________________________________________________________________________________________
void appSystem::AS_updateArrays()
{
	AS_logicOfConsumer = 0;
	AS_physicOfconsumer = 2;
	AS_logicOfSeller = 0;
	AS_physicOfSeller = 2;
	AS_arrayOfconsumer = new consumer*[2];
	AS_arrayOfSeller = new seller*[2];
}
//__________________________________________________________________________________________________
void appSystem::AS_addSeller(seller *ptr)
{
	if (AS_logicOfSeller == AS_physicOfSeller)
	{
		AS_physicOfSeller *= 2;
		seller **tempArray = new seller*[AS_physicOfSeller];
		for (int i = 0; i <= AS_logicOfSeller; i++)
			tempArray[i] = AS_arrayOfSeller[i];
		delete[] AS_arrayOfSeller;
		AS_arrayOfSeller = tempArray;
	}
	AS_arrayOfSeller[AS_logicOfSeller] = ptr;
	AS_logicOfSeller++;
}
//________________________________________________________________________________________
void appSystem::AS_addConsumer(consumer *newConsumer)
{
	if (AS_logicOfConsumer == AS_physicOfconsumer) 
	{
		AS_physicOfconsumer *= 2;
		consumer** tempArray = new consumer*[AS_physicOfconsumer];
		for (int j = 0; j <= AS_logicOfConsumer; j++)
			tempArray[j] = AS_arrayOfconsumer[j];
		delete[] AS_arrayOfconsumer;
		AS_arrayOfconsumer = tempArray;
	}
	AS_arrayOfconsumer[AS_logicOfConsumer] = newConsumer;
	AS_logicOfConsumer++;
}
//____________________________________________________________________________________________________________________
seller * appSystem::AS_createNewSeller()
{
	cout << "enter Your UserName,which supposed to contain  9 digits " << endl;
	char userName[appSystem::MAXSIZEINPUT];
	cin.ignore();
	cin.getline(userName,MAXSIZEINPUT);
	cout << "enter you password supposed,which supposed to contain 5 digits" << endl;
	char password[appSystem::MAXSIZEINPUT];
	cin.getline(password,MAXSIZEINPUT);
	cout << "enter your city of residence" << endl;
	char city[adress::MAX_LENGTH_CITY_STREET];
	cin.getline(city,MAXSIZEINPUT);
	cout << "enter your street of residence" << endl;
	char street[adress::MAX_LENGTH_CITY_STREET];
	cin.getline( street,MAXSIZEINPUT);
	int number;
	cout << "your home number is only digits " << endl;
	cin >> number;
	seller *newSeller = nullptr;
	adress *checkValidityByPtr = nullptr;
	if (checkValidityByPtr->A_checkValidity(city, street, number) == true)
	{
		adress ad(city, street, number);
		if (newSeller->SE_checkValidity(userName, password, ad) == true && AS_existUser(userName) == false)
		{
			newSeller = new seller(userName, password, ad);
		}
		else
			cout << "invalid input  password  or user name is inncorrect... or the username is already taken" << endl;
	}
	else cout << "the adrees is not valid" << endl;
	return newSeller;
}
//__________________________________________________________________________________________________________________________________
consumer* appSystem::AS_createNewConsumer()
{
	cout << "enter Your UserName,which supposed to contain  9 digits :" << endl;
	char userName[appSystem::MAXSIZEINPUT];
	cin.ignore();
	cin.getline(userName, MAXSIZEINPUT);
	
	cout << "enter you password supposed,which supposed to contain 5 digits:" << endl;
	char password[appSystem::MAXSIZEINPUT];
	cin.getline(password, MAXSIZEINPUT);
	
	cout << "enter your city of residence:" << endl;
	char city[adress::MAX_LENGTH_CITY_STREET];
	cin.ignore();
	cin.getline(city, MAXSIZEINPUT);
	cout << "enter your street of residence:" << endl;
	char street[adress::MAX_LENGTH_CITY_STREET];
	cin.getline(street, MAXSIZEINPUT);
	int number;
	cout << "enter yours home number: " << endl;
	cin >> number;
	consumer* newConsumer=nullptr;
	adress *checkValidityByPtr = nullptr;//just in case we have an access to check validity in calss order
	if (checkValidityByPtr->A_checkValidity(city, street, number) == true)
	{
		adress ad(city, street, number);
		if (newConsumer->C_checkValidity(ad, userName, password) == true && AS_existUser(userName) == false)
		{
			newConsumer = new consumer(ad, userName, password);

		}
		else
			cout << "one of the details wasnt correct or the user name is taken" << endl;
	}
	else
		cout << "the adress isnt correct" << endl;
	return newConsumer;
}
//_________________________________________________________________________________________________________________________________
void appSystem::AS_display()// the main menu throgh that menu the program will guide the user
{
	int i;
	bool exitApp = false,returnMainMenu=false;
	cout << "					welcome TO SELL,XOR,BUY      " << endl;
	_sleep(2000);
	system("cls");
	while (exitApp == false) 
	{
		while (returnMainMenu == false) 
		{
			
			cout << "///////////////////////////////////////////////////////////////////////////////////////////////////" << endl;
			cout << "///enter 0- return main menue///  enter 1-to seller////////////////////////////////////////////////" << endl;
			cout << "///enter - 2 to consumer///////// enter 3 - print all seller////////// 4 - print all consumer//////" << endl;
			cout << "///////////////////////////////////////////////////////////////////////////////////////////////////" << endl;
			cin >> i;
			switch (i)
			{
			case 0:
				returnMainMenu = true;
				continue;
			case 1:
				AS_displayForSeller();
				break;
			case 2:
				AS_displayForConsumer();
				break;
			case 3:
		
				cout << "-------all seller names are-------" << endl;
				AS_printAllSellerUserName();
				break;
			case 4:
				
				cout << "-------all consumer names are-------" << endl;

				AS_printAllConsumer();
				break;
			default:
				cout << "wrong input";
				break;
			}
			
		}
		cout << "						continue-0 exit-1      " << endl;
		cin >> exitApp;
		returnMainMenu = false;
	}
	system("cls");
	cout << "--------------thank you for using sell.XOR.buy-----------------" << endl;

}
//__________________________________________________________________________________
void appSystem::AS_displayForConsumer()// when entering for consumer you have to options new/old 
{
	bool stop = false;
	int i;
	system("cls");
	cout << "for main menue -0   for new consumer -1              for old consumer -2" << endl;
	cin >> i;
	switch (i)
	{
	case 0:
	{
		stop = true;
		break;
	}
	case 1:
	{
		consumer *newptr = nullptr;
		while (newptr == nullptr && stop == false)
		{
			newptr = AS_createNewConsumer();
			if (newptr != nullptr)
			{
				AS_addConsumer(newptr);
				AS_cosumerMenu(newptr);
			}
			else
			{
				system("cls");
				cout << "the input is not valid . for try again-0    exit-1" << endl;

				cin >> stop;
			}
		}
		break;
	}
	case 2://the userName is already exist
	{
		cout << "Type your userName" << endl;
		char Username[appSystem::MAXSIZEINPUT];
		cin.ignore();
		cin.getline(Username,MAXSIZEINPUT);
		cout << "ttpe your password" << endl;
		char password[appSystem::MAXSIZEINPUT];
		cin.getline( password,MAXSIZEINPUT);
		consumer *existConsumr = nullptr;
		existConsumr = returnExistConsumer(Username, password);
		if (existConsumr != nullptr)
		{
			AS_cosumerMenu(existConsumr);
			break;
		}
		else
			break;
	}
	default: 
		break;
	}
	
}

//____________________________________________________________________________________________________
void appSystem::AS_cosumerMenu(consumer * cons)// the menu for the consumer
{
	
	int choose;
	bool stop = false;
	while (stop != true)
	{
		cout << "------thinking...------" << endl;
		_sleep(2000);
		system("cls");
		cout << "0- for exit    , 1-for print all product ,  2-print all of the product with specific name     3-show shopping cart "<<endl;
		cout << "4- add feedbackTo specific seller,  5-order" << endl;
		cin >> choose;
		switch (choose)
		{
		case 0:
		{
			stop = true;
			break;
		}
		case 1:
		{
			bool exitproductshow = false;
			int addOrNot;
			AS_printAllProduct();
			while (exitproductshow != true)
			{
				cout << "//////////////////////////////////////////////" << endl;
				cout << "			0-for exit		1-add product to shopping cart     " << endl;
				cin >> addOrNot;
				if (addOrNot == 1)
				{
					int se;
					cout << "type the serial number you want" << endl;
					cin >> se;
					product *productAddtoCart = AS_getProductBySerialNumber(se);
					if (productAddtoCart != nullptr)
						cons->C_addProductToCart(productAddtoCart);
					else
					{
						cout << "serial number isnt exist" << endl;
						exitproductshow = true;
					}
				}
				else
				{
					exitproductshow = true;
				}
			}
			system("cls");
			break;
		}
		case 2:
		{
			cout << "enter the product name you would like to search" << endl;
			char nameForSearch[product::MAX_LENGTH_PRODUCT_NAME];
			cin.ignore();
			cin.getline(nameForSearch, product::MAX_LENGTH_PRODUCT_NAME);
			if (AS_printProductSpecificName(nameForSearch) == false)
			{
				cout << "the product name dosnt exist " << endl;
				continue;
			}
			
			bool exitproductshow = false;
			int addOrNot;
			while (exitproductshow != true)
			{
				cout << "//////////////////////////////////////////////" << endl;
				cout << "			0-for exit		1-add product to shopping cart     " << endl;
				cin >> addOrNot;
				if (addOrNot == 1)
				{
					int se;
					cout << "type the serial number you want" << endl;
					cin >> se;
					product *productAddtoCart = AS_getProductBySerialNumber(se);
					if (productAddtoCart != nullptr)
						cons->C_addProductToCart(productAddtoCart);
					else
					{
						cout << "serial number isnt exist" << endl;
						exitproductshow = true;
					}
				}
				else if(addOrNot==0)
				{
					exitproductshow = true;
				}
			}
			break;
		}
		case 3:
		{
			
			cons->s_printConsumerShoppingCart();
			_sleep(1000);
			break;
		}
		case 4:
		{
			cout << "-------------username of all of the sellers are in the system:---------" << endl;
			if (AS_printAllSellerUserName() == false)//there are no seller
			{
				cout << "there are no seller at the system yet" << endl;
				continue;
			}
			else
			{
				cout << "type the seller username you want to write feedback to" << endl;
				char nameOfSeller[consumer::USER_NAME_LENGTH];
				cin.ignore();
				cin.getline(nameOfSeller,MAXSIZEINPUT);
				seller *ptr = AS_findSellerForFeedback(nameOfSeller);
				if (ptr != nullptr)
				{
					if (ptr->AS_findIfConsumerPurchase(cons) == false) 
					{
						cout << "you havnt purchase nothing from this seller you cant write feedback" << endl;
						continue;
					}
					else 
					{
						feedback newfeedBack = AS_getFeedback(cons);
						if (newfeedBack.C_getConsumer() != nullptr)
							ptr->SE_Addfeedback(newfeedBack);
					}
				}
				else 
				{
					cout << "the seller is not exist" << endl;
					_sleep(1500);
					continue;
				}
			}
			break;
			}
		case 5:
		{
			AS_OrderMenuForConsumer(cons);
			
			break;
		}
		default:
			cout << "you must choose the opptions 0-5" << endl;
			break;
		
		}
	}
}
//_________________________________________________________________________________________________________
void appSystem::AS_printAllProduct()				const
{
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		int sizeofProductArray = AS_arrayOfSeller[i]->SE_getLogicProduct();
		product** temp = AS_arrayOfSeller[i]->SE_getArrayOfProduct();
		for (int j = 0; j < sizeofProductArray; j++)
			temp[j]->print();
	}
}
//_____________________________________________________________________________________________________
bool appSystem::AS_printProductSpecificName(char *name)					const
{
	bool exist = false;
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		int sizeofProductArray = AS_arrayOfSeller[i]->SE_getLogicProduct();
		product** temp = AS_arrayOfSeller[i]->SE_getArrayOfProduct();
		for (int j = 0; j < sizeofProductArray; j++)
		{
			if (strcmp(temp[j]->P_getname(), name) == 0)
			{
				temp[j]->print();
				exist = true;
			}
		}
		}
	return exist;
}
//________________________________________________________________________________________________________________________________
product * appSystem::AS_getProductBySerialNumber(int ser)									const
{
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		int sizeofProductArray = AS_arrayOfSeller[i]->SE_getLogicProduct();
		product** temp = AS_arrayOfSeller[i]->SE_getArrayOfProduct();
		for (int j = 0; j < sizeofProductArray; j++)
		{
			if (temp[j]->P_getSerialNumber() == ser)
				return temp[j];
		}
	}
	return nullptr;
}
//_______________________________________________________________________________________________________________________
bool appSystem::AS_printAllSellerUserName()													const
{
	if (AS_logicOfSeller == 0)
	{
		cout << "there are no seller in the system yet" << endl;
		return false;
	}
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		cout << i<<":" ;
		AS_arrayOfSeller[i]->SE_print();
	}
	return true;
}
//______________________________________________________________________________________________________________________________________
seller* appSystem::AS_findSellerForFeedback(char *name)			const // the function will return the adress of the asked seller if he exist
{
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		if (strcmp(AS_arrayOfSeller[i]->SE_getName(), name) == 0)
			return AS_arrayOfSeller[i];
	}
	return nullptr;
}
//__________________________________________________________________________________________________
feedback appSystem::AS_getFeedback(consumer *cons)// will get the feddback from the consumer and will return it 
{
	int eval;
	char date[MAXSIZEINPUT];
	system("cls");
	cout<<"type the date you purchased from the seller"<<endl;
	cout << "the date supposed to contain 10 digits for example 02.05.1995" << endl;
	cin.getline(date, MAXSIZEINPUT);
	cout << "type your evaluation for the seller" << endl;
	cout << "   0-worst  1- bad  2- average,   3-nice,   4-good,   5-best" << endl;
	cin >> eval;
	if (eval < 0 || eval>5 ||AS_checlValidityOfDate(date)==false )
		return feedback(date, nullptr, (feedback::F_evaluaton)eval, cons->C_getName());//in case of invalid input
	feedback newFeedback(date, cons, (feedback::F_evaluaton)eval, cons->C_getName());
	return newFeedback;
}
//________________________________________________________________________________________________________________________________
void appSystem::AS_printAllConsumer()				const 
{
	for (int i = 0; i < AS_logicOfConsumer; i++)
		cout <<i <<" :"<< AS_arrayOfconsumer[i]->C_getName()<<endl;
	
}
//________________________________________________________________
bool appSystem::AS_existUser(char*name)										const
{
	for (int i = 0; i < AS_logicOfConsumer; i++)
	{
		if (strcmp(AS_arrayOfconsumer[i]->C_getName(), name) == 0)
			return true;
	}
	for (int i = 0; i < AS_logicOfSeller; i++)
	{
		if (strcmp(AS_arrayOfSeller[i]->SE_getName(), name) == 0)
			return true;
	}
	return false;
}
//________________________________________________________________________________________________________________________________
void appSystem::AS_menuForSeller(seller *currSeller)
{
	int acttion;
	system("cls");
	cout << "/////////////////////////////////////////////////" << endl;
	cout << "--------- hello seller:  " << currSeller->SE_getName() <<"---------"<< endl;
	
	bool stop = false;
	while (stop != true)
	{
		_sleep(1500);
		system("cls");
		cout << "0-for exit	 1- for add product     2- for print all of your Feedbacks     3-for print all of your product " << endl;
		cin >> acttion;

		switch (acttion)
		{
		case 0:
		{
			stop = true;
			break;
		}
		case 1:
		{
			cout << "product name is" << endl;
			char P_name[product::MAX_LENGTH_PRODUCT_NAME];
			cin.ignore();
			cin.getline( P_name,product::MAX_LENGTH_PRODUCT_NAME);
			cout << "		0-kids,		1-office,		2-electricity,  3-clothing" << endl;
			int kind;
			cin >> kind;
			float price;
			cout << "the price is? type only digits " << endl;
			cin >> price;
			product* ptr = nullptr;
			if (ptr->P_checkValadity(P_name, (product::P_type)kind, price) == true)
			{
				ptr = new product(P_name, (product::P_type)kind, price, currSeller);
				currSeller->SE_addProduct(ptr);
				cout << "-----added----" << endl;
			}
			else
				cout << "the product is invalid product length supposed tocontain 20 digits max, the descriootion 0-3 " << endl;
			break;
		}
		case 2:
		{
			cout << "--------the feedbacks are-------------" << endl;
			int logicSize = currSeller->SE_getLogicfeedback();
			for (int i = 0; i <logicSize ; i++)
				currSeller->SE_ArrayOfFeedbacks[i].print();
			_sleep(1000);
			break;
		}
		case 3:
			cout << "----------the product are---------------" << endl;
			currSeller->SE_printAllProduct();
			_sleep(1000);
			break;
		default:
			break;
		}

	}

}

void appSystem::AS_OrderMenuForConsumer(consumer *consumerC)
{
	consumerC->C_setOrder();
	order *currentOrder = consumerC->C_getOrder();
	
	shoppingCart *ptr = consumerC->C_getShoppingcart();
	ptr->S_shoppingCartPrint();
	bool exitproductshow = false;
	int addOrNot;
	while (exitproductshow != true)
	{
		cout << "//////////////////////////////////////////////" << endl;
		cout << "			0-for exit		1-add product to order" << endl;
		cin >> addOrNot;
		if (addOrNot == 1)
		{
			int se;
			cout << "type the number of you want" << endl;
			cin >> se;
			product* newproduct = ptr->S_getproductByserialNumber(se);
			if (newproduct != nullptr)
			{
				if (currentOrder->O_checkifProductAlreadyChoose(se) == false)
					currentOrder->O_addItems(newproduct);
				else
					continue;
			}
			else
			{
				cout << "serial number isnt exist" << endl;
				return;

			}
		}
		else if (addOrNot == 0)
		{
			exitproductshow = true;
		}
	}
	system("cls");
	cout << "the product you choose are:" << endl;
	currentOrder->O_print();
	cout << "the price is:   " << currentOrder->O_getPrice() << "$" << endl;
	cout << "are you sure you want to purchase? 1-yes 0-no" << endl;
	int answer;
	cin >> answer;
	if (answer == 1)
	{
		cout << "  -------thank you for tour purchase-----" << endl;
		currentOrder->O_deleteProductFromSeller(consumerC);
		delete (consumerC->C_getShoppingcart());
		consumerC->C_setShoppingCart();
	}
	else
	{
		delete currentOrder;
	}
}
//____________________________________________________________________________
bool appSystem::AS_checlValidityOfDate(char *date)
{
	if (strlen(date) != (feedback::DATE_LENGTH -1) || date[2] != '.' || date[5] != '.')
		return false;
	return true;
}