#ifndef _SE_H
#define _SE_H
#include"consumer.h"
class feedback;
class seller
{
public:
	friend class appSystem;
	~seller();
	seller(const char *SE_userName,const char *SE_password, const adress &a);
	bool SE_checkValidity(const char *SE_userName,const char *SE_password,const adress &a)			const;
	void SE_init( const char *SE_userName,const  char *SE_password, const adress &a);
	void SE_setAdress(const adress& a);
	void SE_setUserName(const char * userName);
	void SE_setPassword(const  char* password);
	void SE_setArrays();
	void SE_addProduct( product* newProdcut);
	void SE_addConsumer(consumer* consumer);
	void SE_print()																					const;
	void  SE_Addfeedback(const feedback& feed);
	bool  SE_consumerIsInTheArray(const feedback& feed);
	const char*SE_getName()																			const;
	const char*SE_getPassword()																		const;
	 void AS_sellerMenu();
	 const int & SE_getLogicProduct()																const;
	 product	** SE_getArrayOfProduct()															const;
	 void SE_setLogic(int sizeOfP);
	 bool SE_isconsumerInTheArray(consumer* cons);
	 bool AS_findIfConsumerPurchase(consumer * ptr);
	 const int& SE_getLogicfeedback()																const;
	 void SE_printAllProduct()																		const;
private:
	feedback *SE_ArrayOfFeedbacks;
	int SE_logicFeedbcak, SE_physicFeedback;
	product** SE_arrayOfProduct;
	int SE_logicAraayProduct, SE_physicArrayProduct;
	char SE_userName[consumer::USER_NAME_LENGTH];
	char SE_password[consumer::PASSWORD_LENGTH];
	adress SE_adress;
	consumer ** SE_arrayOfPurchaseConsumers;
	int SE_logicOfArrayconsumers, SE_physicOfArrayConsumer;
};
#endif // !_SE_H
