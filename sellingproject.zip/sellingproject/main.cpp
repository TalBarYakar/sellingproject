#include"product.h"
#include"consumer.h"
#include"seller.h"
#include"feedback.h"
#include"appSystem.h"
int main()
{

	appSystem a;
	a.AS_display();
	system("pause");
}