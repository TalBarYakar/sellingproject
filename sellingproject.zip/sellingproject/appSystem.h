#ifndef _AS_H
#define _AS_H
#include"seller.h"
#include "consumer.h"
class appSystem 
{
public:
	static const int MAXSIZEINPUT = 20;
	appSystem();
	~appSystem();
	void AS_updateArrays();
	void AS_addSeller(seller *ptr);
	void AS_addConsumer(consumer * newConsumer);
	seller *AS_createNewSeller();
	consumer *AS_createNewConsumer();
	void AS_display();
	void AS_displayForConsumer();
	consumer* returnExistConsumer(const char*name, const char*password)const;
	void AS_displayForSeller();
	seller* AS_returnExistSeller(const char* name, const char* password)const;
	void AS_cosumerMenu(consumer *cons);
	void AS_printAllProduct()											const;
	bool AS_printProductSpecificName(char *name)						const;
	void AS_printShoppingCart()											const;
 	product*   AS_getProductBySerialNumber(int serial)					const;
	bool AS_printAllSellerUserName()									const;
	seller* AS_findSellerForFeedback(char *name)						const;
	void AS_printAllConsumer()				const;
	feedback AS_getFeedback(consumer *cons);
	bool AS_existUser(char*name)										const;
	void AS_menuForSeller(seller *currSeller);
	void AS_OrderMenuForConsumer(consumer *consumer);
	bool AS_checlValidityOfDate(char *date);
private:
	consumer** AS_arrayOfconsumer;
	seller** AS_arrayOfSeller;
	int AS_logicOfConsumer, AS_physicOfconsumer;
	int AS_logicOfSeller, AS_physicOfSeller;

};
#endif // !_AS_H
